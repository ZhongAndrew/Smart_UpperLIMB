//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: extract_features_initialize.h
//
// MATLAB Coder version            : 25.2
// C/C++ source code generated on  : 30-Mar-2026 10:32:12
//

#ifndef EXTRACT_FEATURES_INITIALIZE_H
#define EXTRACT_FEATURES_INITIALIZE_H

// Include Files
#include "rtwtypes.h"
#include <cstddef>
#include <cstdlib>

// Function Declarations
namespace feature_exraction {
extern void extract_features_initialize();

}

#endif
//
// File trailer for extract_features_initialize.h
//
// [EOF]
//
