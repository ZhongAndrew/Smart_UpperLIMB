//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: genc_terminate.cpp
//
// MATLAB Coder version            : 25.2
// C/C++ source code generated on  : 11-Apr-2026 09:57:11
//

// Include Files
#include "genc_terminate.h"

// Function Definitions
//
// Arguments    : void
// Return Type  : void
//
namespace layer1 {
void genc_terminate()
{
}

} // namespace layer1

//
// File trailer for genc_terminate.cpp
//
// [EOF]
//
