//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: predictOneWithCache.cpp
//
// MATLAB Coder version            : 25.2
// C/C++ source code generated on  : 11-Apr-2026 09:57:11
//

// Include Files
#include "predictOneWithCache.h"
#include "CompactClassificationTree.h"
#include "updateCache.h"
#include <cmath>

// Function Definitions
//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::ab_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
namespace layer1 {
namespace coder {
namespace classreg {
namespace learning {
namespace coder {
namespace ensembleutils {
void ab_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                ab_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::b_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void b_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               b_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::bb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void bb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                bb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::c_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void c_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               c_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::cb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void cb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                cb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::d_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void d_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               d_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::db_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void db_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                db_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::e_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void e_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               e_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::eb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void eb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                eb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::f_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void f_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               f_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::fb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void fb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                fb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::g_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void g_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               g_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::gb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void gb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                gb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::h_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void h_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               h_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::hb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void hb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                hb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::i_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void i_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               i_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::ib_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void ib_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                ib_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::j_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void j_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               j_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::jb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void jb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                jb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::k_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void k_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               k_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::kb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void kb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                kb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::l_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void l_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               l_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::lb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void lb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                lb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::m_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void m_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               m_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::mb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void mb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                mb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::n_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void n_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               n_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::nb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void nb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                nb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::o_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void o_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               o_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::ob_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void ob_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                ob_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::p_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void p_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               p_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::pb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void pb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                pb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::CompactClassificationTree
//                &weak_learner bool &cached bool initCache double score[2]
// Return Type  : void
//
void predictOneWithCache(const double X[280], double cachedScore[2],
                         double &cachedWeights, const char combiner[15],
                         const ::layer1::coder::classreg::learning::classif::
                             CompactClassificationTree &weak_learner,
                         bool &cached, bool initCache, double score[2])
{
  double dv[2];
  weak_learner.predict(X, dv);
  if (initCache) {
    cachedScore[0] = 0.0;
    cachedScore[1] = 0.0;
  } else {
    int k;
    bool exitg1;
    bool y;
    y = false;
    k = 0;
    exitg1 = false;
    while ((!exitg1) && (k < 2)) {
      if (std::isnan(cachedScore[k])) {
        y = true;
        exitg1 = true;
      } else {
        k++;
      }
    }
    if (y) {
      if (std::isnan(cachedScore[0])) {
        cachedScore[0] = 0.0;
      }
      if (std::isnan(cachedScore[1])) {
        cachedScore[1] = 0.0;
      }
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::q_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void q_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               q_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::qb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void qb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                qb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::r_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void r_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               r_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::rb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void rb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                rb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::s_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void s_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               s_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::sb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void sb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                sb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::t_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void t_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               t_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::tb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void tb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                tb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::u_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void u_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               u_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::ub_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void ub_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                ub_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::v_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void v_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               v_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::vb_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void vb_predictOneWithCache(const double X[280], double cachedScore[2],
                            double &cachedWeights, const char combiner[15],
                            const ::layer1::coder::classreg::learning::classif::
                                vb_CompactClassificationTree &weak_learner,
                            bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::w_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void w_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               w_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::x_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void x_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               x_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

//
// Arguments    : const double X[280]
//                double cachedScore[2]
//                double &cachedWeights
//                const char combiner[15]
//                const
//                ::layer1::coder::classreg::learning::classif::y_CompactClassificationTree
//                &weak_learner bool &cached double score[2]
// Return Type  : void
//
void y_predictOneWithCache(const double X[280], double cachedScore[2],
                           double &cachedWeights, const char combiner[15],
                           const ::layer1::coder::classreg::learning::classif::
                               y_CompactClassificationTree &weak_learner,
                           bool &cached, double score[2])
{
  double dv[2];
  int k;
  bool exitg1;
  bool y;
  weak_learner.predict(X, dv);
  y = false;
  k = 0;
  exitg1 = false;
  while ((!exitg1) && (k < 2)) {
    if (std::isnan(cachedScore[k])) {
      y = true;
      exitg1 = true;
    } else {
      k++;
    }
  }
  if (y) {
    if (std::isnan(cachedScore[0])) {
      cachedScore[0] = 0.0;
    }
    if (std::isnan(cachedScore[1])) {
      cachedScore[1] = 0.0;
    }
  }
  updateCache(dv, cachedScore, cachedWeights, cached, combiner, score);
}

} // namespace ensembleutils
} // namespace coder
} // namespace learning
} // namespace classreg
} // namespace coder
} // namespace layer1

//
// File trailer for predictOneWithCache.cpp
//
// [EOF]
//
